import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const apiKey = process.env.OPENAI_API_KEY;
const client = apiKey ? new OpenAI({ apiKey }) : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(client) });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) {
      return res.status(503).json({
        error: "AI is not configured. Add OPENAI_API_KEY to the server environment."
      });
    }
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    const history = Array.isArray(req.body?.history) ? req.body.history : [];
    const language = typeof req.body?.language === "string" ? req.body.language : "so";
    if (!message) return res.status(400).json({ error: "Message is required." });

    // Keep a short, validated conversation context. Never accept API keys from the browser.
    const safeHistory = history.slice(-12).filter(x =>
      x && ["user", "assistant"].includes(x.role) &&
      typeof x.content === "string"
    ).map(x => ({ role: x.role, content: x.content.slice(0, 6000) }));

    const languageNames = {
      so: "Somali", en: "English", ar: "Arabic", fr: "French",
      es: "Spanish", hi: "Hindi", zh: "Chinese"
    };
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6.2-sol",
      instructions: `You are NetChat AI, a helpful, accurate, friendly general-purpose assistant. Reply in ${languageNames[language] || "the language used by the user"} unless the user asks otherwise. For Somali, use natural clear Somali. Be honest about uncertainty and do not claim to perform actions you cannot perform.`,
      input: [
        ...safeHistory,
        { role: "user", content: message }
      ],
      max_output_tokens: 1200
    });
    res.json({ reply: response.output_text || "I couldn't produce a response. Please try again." });
  } catch (err) {
    console.error("Chat API error:", err?.message || err);
    res.status(500).json({ error: "The AI request failed. Check server configuration and try again." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`NetChat AI listening on ${port}`));
