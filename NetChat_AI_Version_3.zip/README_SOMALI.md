# NetChat AI Version 3 — AI dhab ah

Noocan wuxuu leeyahay frontend iyo backend. Browser-ku **ma arko API key-ga**; furaha waxaa lagu hayaa environment variable-ka server-ka.

## Sida loo bilaabo (Replit ama Node.js hosting)
1. Samee Node.js project cusub oo geli dhammaan faylasha ZIP-kan.
2. Ku dar Secrets / Environment Variables:
   - `OPENAI_API_KEY` = furahaaga OpenAI API (sir ha ahaado).
   - `OPENAI_MODEL` = `gpt-6.2-sol` (ikhtiyaari).
3. Orod `npm install`, kadib `npm start`.
4. Fur URL-ka app-ka. `/api/health` wuxuu muujinayaa in server-ku helay furaha (ma soo bandhigo furaha).
5. Tijaabi chat-ka.

## API key
API key waa in laga sameeyaa OpenAI Platform. ChatGPT subscription iyo API billing waa kala gaar. Ha ku qorin key-ga HTML/JavaScript-ka, hana ii soo dirin aniga ama qof kale.

## Endpoint
`POST /api/chat`
Body: `{"message":"Salaan","history":[],"language":"so"}`
Response: `{"reply":"..."}`

## Xusuusin
- API usage wuxuu yeelan karaa kharash; dejiso usage limits/budget gudaha platform-ka.
- Tani waa starter project, ma aha adeeg production oo dhammaystiran. Kahor isticmaal dadweyne ku dar authentication, rate limiting, HTTPS, iyo xaddidaad isticmaal.
- Isku xirka AI wuxuu shaqaynayaa kaliya marka `OPENAI_API_KEY` sax ah lagu daro server-ka.
